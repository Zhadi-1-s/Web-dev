export interface Product {
  id: number;
  name: string;
  price: number;
  description: string;
}

export const products = [
  {
    id: 1,
    name: 'Toyota Tundra',
    price: 10000,
    description: 'Very big car for very big guys like you and me  '
  },
  {
    id: 2,
    name: 'Dodge RAM',
    price: 13000,
    description: 'Bigger than tundra)'
  },
  {
    id: 3,
    name: 'Ford F150',
    price: 12000,
    description: 'Another big car for big guys'
  },
  {
    id:4,
    name:'Folkswagen Golf 7',
    price:6000,
    description:'Easy to buy with TFSI MOtor'
  },
  {
    id:5,
    name:'Toyota Corolla',
    price:6000,
    description:'Cheap car to students'
  },
  {
    id:6,
    name:'Mercedes Benz E-class w 213',
    price:8000,
    description:'Legendary car,there is no need to describe'
  },
  {
    id:7,
    name:'Bmw 5 series G30',
    price:8000,
    description:'Another legendary car '
  },
  {
    id:8,
    name:'Porche Cayene',
    price:12000,
    description:'if you want big car with porche 911 engine, you welcome '
  },
  {
    id:9,
    name:'Toyota Camry',
    price:7000,
    description:'Just a car to drive not more'
  },
  {
    id:10,
    name:'Mercedes Benz S-class w 223',
    price:16000,
    description:'For really mans '
  }
];


/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at https://angular.io/license
*/